<?php
namespace Flow\JSONPath;

use Exception;

class JSONPathException extends Exception
{

}
 