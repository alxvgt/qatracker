---
name: ⚙ Improvement
about: You have some improvement to make PHPUnit better?
labels: type/enhancement
---

<!--
- Please target the master branch of PHPUnit.
-->
