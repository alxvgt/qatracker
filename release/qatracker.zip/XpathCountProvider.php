<?php

namespace Alxvng\QATracker\DataProvider;

use Alxvng\QATracker\DataProvider\Reducer\CountReducerTrait;

class XpathCountProvider extends AbstractXpathReducerProvider
{
    use CountReducerTrait;
}
