<?php


namespace App\DataProvider;

use App\DataProvider\Reducer\CountReducerTrait;

class XpathCountProvider extends AbstractXpathReducerProvider
{
    use CountReducerTrait;
}