<?php

namespace Alxvng\QATracker\DataProvider;

use Alxvng\QATracker\DataProvider\Reducer\SumReducerTrait;

class XpathSumProvider extends AbstractXpathReducerProvider
{
    use SumReducerTrait;
}
