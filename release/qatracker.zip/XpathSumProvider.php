<?php


namespace App\DataProvider;

use App\DataProvider\Reducer\SumReducerTrait;

class XpathSumProvider extends AbstractXpathReducerProvider
{
    use SumReducerTrait;
}