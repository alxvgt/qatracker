<?php


namespace App\DataProvider;

use App\DataProvider\Reducer\AverageReducerTrait;

class XpathAverageProvider extends AbstractXpathReducerProvider
{
    use AverageReducerTrait;
}