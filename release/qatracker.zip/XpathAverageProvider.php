<?php

namespace Alxvng\QATracker\DataProvider;

use Alxvng\QATracker\DataProvider\Reducer\AverageReducerTrait;

class XpathAverageProvider extends AbstractXpathReducerProvider
{
    use AverageReducerTrait;
}
